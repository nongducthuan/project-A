const productModel = require("../models/productModel");

/* ============================================================
   LẤY SẢN PHẨM ĐẠI DIỆN CHO DANH MỤC
   ============================================================ */
async function getRepresentative(req, res) {
  const { category_id } = req.query;
  if (!category_id) return res.status(400).json({ message: "Thiếu category_id" });

  try {
    const product = await productModel.getRepresentativeProduct(category_id);
    if (!product)
      return res.status(404).json({ message: "Không tìm thấy sản phẩm" });

    res.json(product);
  } catch (err) {
    console.error("❌ Lỗi getRepresentative:", err);
    res.status(500).json({ message: "Lỗi server" });
  }
}

/* ============================================================
   LẤY DANH SÁCH SẢN PHẨM (Trang CategoryPage)
   Hỗ trợ filter: category_id + gender + phân trang
   ============================================================ */
async function getProducts(req, res) {
  try {
    const { category_id, gender, page = 1, limit = 8 } = req.query;

    const p = parseInt(page);
    const l = parseInt(limit);
    const offset = (p - 1) * l;

    const products = await productModel.getAllProducts(
      category_id,
      gender,
      l,
      offset
    );

    const totalProducts = await productModel.countProducts(
      category_id,
      gender
    );

    const totalPages = Math.ceil(totalProducts / l);

    res.json({
      data: products,
      products,
      totalPages,
      currentPage: p,
      totalProducts,
    });
  } catch (err) {
    console.error("❌ Lỗi getProducts:", err);
    res.status(500).json({ message: "Lỗi server khi lấy danh sách sản phẩm" });
  }
}

/* ============================================================
   TÌM KIẾM SẢN PHẨM
   ============================================================ */
async function searchProducts(req, res) {
  try {
    const { q, gender, category, page = 1, limit = 8 } = req.query;

    const p = parseInt(page);
    const l = parseInt(limit);
    const offset = (p - 1) * l;

    const products = await productModel.searchProductsInModel(
      q,
      gender,
      category,
      l,
      offset
    );

    const totalProducts = await productModel.countSearchedProducts(
      q,
      gender,
      category
    );

    const totalPages = Math.ceil(totalProducts / l);

    res.json({
      data: products,
      products,
      totalPages,
      currentPage: p,
      totalProducts,
    });
  } catch (err) {
    console.error("❌ Lỗi searchProducts:", err);
    res.status(500).json({ message: "Lỗi server khi tìm kiếm" });
  }
}

/* ============================================================
   LẤY CHI TIẾT 1 SẢN PHẨM
   ============================================================ */
async function getProduct(req, res) {
  try {
    const { id } = req.params;

    const product = await productModel.getProductById(id);
    if (!product)
      return res.status(404).json({ message: "Không tìm thấy sản phẩm" });

    res.json(product);
  } catch (err) {
    console.error("❌ Lỗi getProduct:", err);
    res.status(500).json({ message: "Lỗi server" });
  }
}

/* ============================================================
   LẤY LIST OPTION (SIZE/STOCK) CỦA SẢN PHẨM
   ============================================================ */
async function getProductOptions(req, res) {
  try {
    const { id } = req.params;

    const options = await productModel.getProductOptionsById(id);
    res.json(options);
  } catch (err) {
    console.error("❌ Lỗi getProductOptions:", err);
    res.status(500).json({ message: "Lỗi server" });
  }
}

/* ============================================================
   EXPORT CONTROLLER
   ============================================================ */
module.exports = {
  getRepresentative,
  getProducts,
  searchProducts,
  getProduct,
  getProductOptions,
};

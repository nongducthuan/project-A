// controllers/categoryController.js
const categoryModel = require("../models/categoryModel");

/**
 * GET /categories
 * Lấy tất cả categories (admin table)
 */
async function getCategories(req, res) {
  try {
    const categories = await categoryModel.getAllCategories();
    res.status(200).json({ data: categories });
  } catch (err) {
    console.error("getCategories error:", err);
    res.status(500).json({ message: "Lỗi khi lấy danh mục" });
  }
}

/**
 * GET /categories/recommend?gender=...
 * Gợi ý danh mục chưa có theo gender
 */
async function getRecommendCategories(req, res) {
  try {
    const gender = req.query.gender;
    if (!gender) return res.status(400).json({ message: "Thiếu gender" });

    const result = await categoryModel.getRecommendCategoriesForGender(gender);
    res.json({ data: result });
  } catch (err) {
    console.error("getRecommendCategories error:", err);
    res.status(500).json({ message: "Lỗi lấy danh mục gợi ý" });
  }
}

/**
 * GET /categories/with-preview
 * Lấy categories (dùng cho navbar) kèm preview_image
 */
async function getCategoriesWithPreview(req, res) {
  try {
    const rows = await categoryModel.getCategoriesWithPreview();
    res.status(200).json({ data: rows });
  } catch (err) {
    console.error("getCategoriesWithPreview error:", err);
    res.status(500).json({ message: "Lỗi khi lấy danh mục preview" });
  }
}

/**
 * POST /categories  (admin)
 */
async function createCategory(req, res) {
  try {
    const id = await categoryModel.createCategory(req.body);
    res.status(201).json({ message: "Tạo thành công", id });
  } catch (err) {
    console.error("createCategory error:", err);
    res.status(500).json({ message: "Lỗi khi thêm danh mục" });
  }
}

/**
 * PUT /categories/:id  (admin)
 */
async function updateCategory(req, res) {
  try {
    const rows = await categoryModel.updateCategory(req.params.id, req.body);
    if (rows === 0) return res.status(404).json({ message: "Không tìm thấy danh mục" });
    res.json({ message: "Cập nhật thành công" });
  } catch (err) {
    console.error("updateCategory error:", err);
    res.status(500).json({ message: "Lỗi khi cập nhật danh mục" });
  }
}

/**
 * DELETE /categories/:id  (admin)
 */
async function deleteCategory(req, res) {
  try {
    const rows = await categoryModel.deleteCategory(req.params.id);
    if (rows === 0) return res.status(404).json({ message: "Không tìm thấy danh mục" });
    res.json({ message: "Xóa thành công" });
  } catch (err) {
    console.error("deleteCategory error:", err);
    res.status(500).json({ message: "Lỗi khi xóa danh mục" });
  }
}

/**
 * GET /categories/:id/images
 * Lấy list ảnh liên quan để chọn ảnh đại diện khi edit
 */
async function getCategoryImages(req, res) {
  try {
    const images = await categoryModel.getCategoryImages(req.params.id);
    res.json({ data: images });
  } catch (err) {
    console.error("getCategoryImages error:", err);
    res.status(500).json({ message: "Lỗi lấy ảnh danh mục" });
  }
}

module.exports = {
  getCategories,
  getRecommendCategories,
  getCategoriesWithPreview,
  createCategory,
  updateCategory,
  deleteCategory,
  getCategoryImages,
};

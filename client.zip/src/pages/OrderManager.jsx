import { useState, useEffect } from "react";
import API from "../api.jsx";
import Toast from "../pages/Toast.jsx";

export default function OrderManager() {
  const [orders, setOrders] = useState([]);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [toast, setToast] = useState(null);
  const [confirmAction, setConfirmAction] = useState(false);
  const [filterStatus, setFilterStatus] = useState("Tất cả");
  const token = localStorage.getItem("token");

  const showToast = (message, type = "success") => {
    setToast({ message, type });
  };

  const fetchOrders = async () => {
    try {
      const res = await API.get("/admin/orders", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const sortedOrders = res.data.sort((a, b) => new Date(b.created_at) - new Date(a.created_at)); // Mới nhất lên đầu
      setOrders(sortedOrders);
    } catch (err) {
      console.error(err);
      showToast("Lỗi tải danh sách đơn hàng", "error");
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleChangeStatus = async (orderId, status) => {
    try {
      await API.put(
        `/admin/orders/${orderId}`,
        { status },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      fetchOrders();
      if (selectedOrder && selectedOrder.id === orderId) {
        setSelectedOrder(prev => ({ ...prev, status }));
      }
      showToast(`Đã cập nhật: ${status}`, "success");
    } catch (err) {
      console.error(err);
      showToast(err.response?.data?.message || err.message, "error");
    }
  };

  const formatCurrency = (amount) => Number(amount).toLocaleString("vi-VN") + " đ";

  const getStatusColor = (status) => {
    switch (status) {
      case "Chờ xác nhận": return "#ffc107"; // Vàng
      case "Đã xác nhận": return "#17a2b8"; // Cyan
      case "Đang giao hàng": return "#007bff"; // Blue
      case "Đã giao hàng": return "#28a745"; // Green
      case "Đã hủy": return "#dc3545"; // Red
      default: return "#6c757d";
    }
  };

  // Lọc đơn hàng
  const filteredOrders = orders.filter(order => filterStatus === "Tất cả" || order.status === filterStatus);

  return (
    <div className="container mx-auto p-4 mb-20">
      {toast && (
        <Toast
          message={toast.message}
          type={toast.type}
          onClose={() => setToast(null)}
        />
      )}

      <h2 className="text-center text-2xl font-bold mb-6 uppercase text-gray-800">Quản lý Đơn hàng</h2>

      {/* Filter Bar */}
      <div className="flex justify-end mb-4">
        <div className="relative w-full md:w-auto">
          <select
            className="w-full md:w-48 p-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
          >
            <option value="Tất cả">Tất cả trạng thái</option>
            <option value="Chờ xác nhận">Chờ xác nhận</option>
            <option value="Đã xác nhận">Đã xác nhận</option>
            <option value="Đang giao hàng">Đang giao hàng</option>
            <option value="Đã giao hàng">Đã giao hàng</option>
            <option value="Đã hủy">Đã hủy</option>
          </select>
        </div>
      </div>

      {filteredOrders.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-lg border border-dashed border-gray-300 text-gray-500">
          <i className="fa-regular fa-folder-open text-4xl mb-3 block"></i>
          Chưa có đơn hàng nào.
        </div>
      ) : (
        <>
          {/* --- GIAO DIỆN MOBILE (CARD VIEW) --- */}
          <div className="grid grid-cols-1 gap-4 md:hidden">
            {filteredOrders.map((order) => (
              <div key={order.id} className="bg-white p-4 rounded-lg shadow border border-gray-100 relative">
                {/* Badge trạng thái ở góc */}
                <div className="absolute top-4 right-4">
                  <span className="px-2 py-1 rounded text-xs font-bold text-white shadow-sm" style={{ backgroundColor: getStatusColor(order.status) }}>
                    {order.status}
                  </span>
                </div>

                {/* Thông tin chính */}
                <div className="mb-2 pr-20">
                  <p className="font-bold text-gray-800">#{order.id} - {order.user_name}</p>
                  <p className="text-xs text-gray-500">{new Date(order.created_at).toLocaleString("vi-VN")}</p>
                </div>

                <div className="flex justify-between items-center mb-3">
                  <span className="text-sm text-gray-600">Tổng tiền:</span>
                  <span className="text-red-600 font-bold text-lg">{formatCurrency(order.total_price)}</span>
                </div>

                {/* Hành động */}
                <div className="flex gap-2 mt-3 pt-3 border-t">
                  <button
                    onClick={() => { setSelectedOrder(order); setConfirmAction(false); }}
                    className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 rounded text-sm font-medium transition"
                  >
                    Chi tiết
                  </button>
                  {/* Select đổi trạng thái nhanh trên mobile */}
                  <select
                    value={order.status}
                    onChange={(e) => handleChangeStatus(order.id, e.target.value)}
                    className="flex-1 bg-white border border-gray-300 text-gray-700 py-2 rounded text-sm pl-2 focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="Chờ xác nhận">Chờ xác nhận</option>
                    <option value="Đã xác nhận">Đã xác nhận</option>
                    <option value="Đang giao hàng">Đang giao</option>
                    <option value="Đã giao hàng">Đã giao</option>
                    <option value="Đã hủy">Hủy đơn</option>
                  </select>
                </div>
              </div>
            ))}
          </div>

          {/* --- GIAO DIỆN DESKTOP (TABLE VIEW) --- */}
          <div className="hidden md:block overflow-hidden rounded-lg shadow border border-gray-200">
            <table className="min-w-full bg-white">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mã / Ngày</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Khách hàng</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tổng tiền</th>
                  <th className="py-3 px-4 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Trạng thái</th>
                  <th className="py-3 px-4 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Hành động</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 transition">
                    <td className="py-4 px-4 whitespace-nowrap">
                      <div className="text-sm font-bold text-gray-900">#{order.id}</div>
                      <div className="text-xs text-gray-500">{new Date(order.created_at).toLocaleDateString("vi-VN")}</div>
                    </td>
                    <td className="py-4 px-4">
                      <div className="text-sm font-medium text-gray-900">{order.user_name}</div>
                      <div className="text-xs text-gray-500">{order.phone}</div>
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap text-sm text-red-600 font-bold">
                      {formatCurrency(order.total_price)}
                    </td>
                    <td className="py-4 px-4 whitespace-nowrap">
                      <select
                        value={order.status}
                        onChange={(e) => handleChangeStatus(order.id, e.target.value)}
                        className="text-xs font-bold text-white py-1 px-2 rounded cursor-pointer border-0 focus:ring-2 focus:ring-offset-1"
                        style={{ backgroundColor: getStatusColor(order.status) }}
                      >
                        <option value="Chờ xác nhận" className="text-gray-800 bg-white">Chờ xác nhận</option>
                        <option value="Đã xác nhận" className="text-gray-800 bg-white">Đã xác nhận</option>
                        <option value="Đang giao hàng" className="text-gray-800 bg-white">Đang giao hàng</option>
                        <option value="Đã giao hàng" className="text-gray-800 bg-white">Đã giao hàng</option>
                        <option value="Đã hủy" className="text-gray-800 bg-white">Đã hủy</option>
                      </select>
                    </td>
                    <td className="py-4 px-4 text-center whitespace-nowrap">
                      <button
                        onClick={() => { setSelectedOrder(order); setConfirmAction(false); }}
                        className="text-blue-600 hover:text-blue-900 font-medium text-sm border border-blue-600 px-3 py-1 rounded hover:bg-blue-50 transition"
                      >
                        Chi tiết
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* --- MODAL CHI TIẾT --- */}
      {selectedOrder && (
        // SỬA 1: Thay bg-black bg-opacity-60 thành bg-black/60 (cú pháp mới an toàn hơn)
        // Hoặc dùng style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} để chắc chắn trong suốt
        <div
          className="fixed inset-0 z-50 flex justify-center items-center p-4"
          style={{ backgroundColor: "rgba(0, 0, 0, 0.6)" }} // Dùng inline style để đảm bảo 100% không bị đen thui
        >
          {/* SỬA 2: Thêm relative và z-index cao hơn cho hộp thoại trắng để nó nổi lên trên */}
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col animate-scaleIn relative z-50">

            {/* Header */}
            <div className="flex justify-between items-center p-4 border-b">
              <h4 className="text-lg font-bold text-gray-800">Chi tiết đơn hàng #{selectedOrder.id}</h4>
              <button onClick={() => setSelectedOrder(null)} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">&times;</button>
            </div>

            {/* Scrollable Body */}
            <div className="p-4 overflow-y-auto custom-scrollbar">
              {/* Thông tin khách hàng Responsive */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mb-4 text-sm">
                <h5 className="font-bold text-blue-800 mb-2 uppercase text-xs">Thông tin giao hàng</h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <p><span className="font-semibold text-gray-600">Người nhận:</span> {selectedOrder.user_name}</p>
                  <p><span className="font-semibold text-gray-600">SĐT:</span> {selectedOrder.phone}</p>
                  <p className="sm:col-span-2"><span className="font-semibold text-gray-600">Địa chỉ:</span> {selectedOrder.address}</p>
                  <p><span className="font-semibold text-gray-600">Ngày đặt:</span> {new Date(selectedOrder.created_at).toLocaleString("vi-VN")}</p>
                </div>
              </div>

              {/* Danh sách sản phẩm Responsive */}
              <h5 className="font-bold text-gray-800 mb-2 text-sm uppercase">Sản phẩm ({selectedOrder.items?.length})</h5>
              <div className="space-y-3">
                {selectedOrder.items && selectedOrder.items.map((item, idx) => (
                  <div key={idx} className="flex gap-3 bg-white border rounded p-2 items-start">
                    <img
                      src={item.image_url?.startsWith('http') ? item.image_url : `http://localhost:5000${item.image_url}`}
                      onError={(e) => e.target.src = "http://localhost:5000/public/placeholder.jpg"}
                      alt=""
                      className="w-16 h-16 object-cover rounded border bg-gray-50 flex-shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-800 truncate">{item.product_name}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {item.color_name && `Màu: ${item.color_name}`}
                        {item.size && ` | Size: ${item.size}`}
                      </p>
                      <div className="flex justify-between items-end mt-2">
                        <span className="text-xs bg-gray-100 px-2 py-0.5 rounded text-gray-600">x{item.quantity}</span>
                        <span className="text-sm font-bold text-gray-900">{formatCurrency(item.price * item.quantity)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-between items-center mt-4 pt-4 border-t">
                <span className="font-bold text-gray-600">Tổng cộng:</span>
                <span className="text-xl font-bold text-red-600">{formatCurrency(selectedOrder.total_price)}</span>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-gray-50 rounded-b-xl flex justify-end gap-3">
              <button
                className="px-4 py-2 bg-white border border-gray-300 hover:bg-gray-100 text-gray-700 rounded-lg text-sm font-medium transition"
                onClick={() => setSelectedOrder(null)}
              >
                Đóng
              </button>

              {selectedOrder.status === "Chờ xác nhận" && (
                confirmAction ? (
                  <button
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg text-sm font-bold transition animate-pulse"
                    onClick={() => {
                      handleChangeStatus(selectedOrder.id, "Đã xác nhận");
                      setConfirmAction(false);
                    }}
                    onMouseLeave={() => setConfirmAction(false)}
                  >
                    Xác nhận ngay?
                  </button>
                ) : (
                  <button
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-bold transition flex items-center gap-2"
                    onClick={() => setConfirmAction(true)}
                  >
                    <i className="fa-solid fa-check"></i> Duyệt đơn
                  </button>
                )
              )}
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
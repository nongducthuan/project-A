import { useState, useEffect, useMemo, Fragment } from "react";
import { useNavigate } from "react-router-dom";
import { Listbox, Transition } from "@headlessui/react";
import { FaChevronDown } from "react-icons/fa6";
import API from "../api.jsx";

export default function ProductManager() {
  const navigate = useNavigate();
  const backendUrl = "http://localhost:5000";
  const token = localStorage.getItem("token");

  // ==========================
  // STATE
  // ==========================
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [uploading, setUploading] = useState(false);

  const [filterGender, setFilterGender] = useState("all");
  const [filterCategory, setFilterCategory] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const [editingId, setEditingId] = useState(null);

  const [form, setForm] = useState({
    name: "",
    description: "",
    price: "",
    image_url: "",
    gender: "unisex",
    category_id: "",
  });

  // ==========================
  // FETCH DATA
  // ==========================
  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    // Khi đổi filter giới tính → reset filter danh mục
    setFilterCategory("all");
  }, [filterGender]);

  const fetchData = async () => {
    try {
      const [prodRes, catRes] = await Promise.all([
        API.get("/admin/products", { headers: { Authorization: `Bearer ${token}` } }),
        API.get("/categories"),
      ]);

      setProducts(Array.isArray(prodRes.data) ? prodRes.data : []);
      setCategories(Array.isArray(catRes.data) ? catRes.data : catRes.data?.data || []);
    } catch (err) {
      console.error("Lỗi tải dữ liệu:", err);
    }
  };

  // ==========================
  // UPLOAD ẢNH
  // ==========================
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append("image", file);

    try {
      const res = await API.post("/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setForm((prev) => ({ ...prev, image_url: res.data.url }));
    } catch {
      alert("Lỗi upload ảnh");
    } finally {
      setUploading(false);
    }
  };

  // ==========================
  // FILTER + SORT
  // ==========================
  const sortGenderOrder = (list) => {
    const order = { male: 1, female: 2, unisex: 3 };
    return [...list].sort((a, b) => order[a.gender] - order[b.gender]);
  };

  const filteredProducts = useMemo(() => {
    const sorted = sortGenderOrder(products);

    return sorted.filter((p) => {
      const matchGender = filterGender === "all" || p.gender === filterGender;
      const matchCategory = filterCategory === "all" || p.category_id == filterCategory;
      const matchSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
      return matchGender && matchCategory && matchSearch;
    });
  }, [products, filterGender, filterCategory, searchTerm]);

  // ==========================
  // SUBMIT (CREATE / UPDATE)
  // ==========================
  const handleSubmit = async (e) => {
    e.preventDefault();

    const cleanName = form.name.trim();
    const cleanDesc = form.description.trim();

    if (!cleanName || !form.price || !form.category_id)
      return alert("Vui lòng nhập đủ thông tin!");

    // Kiểm tra giới tính
    const selectedCategory = categories.find((c) => c.id == form.category_id);
    if (selectedCategory && selectedCategory.gender !== form.gender)
      return alert("Giới tính sản phẩm phải trùng với danh mục!");

    const payload = { ...form, name: cleanName, description: cleanDesc };

    try {
      const endpoint = editingId
        ? `/admin/products/${editingId}`
        : "/admin/products";

      const method = editingId ? API.put : API.post;

      const res = await method(endpoint, payload, {
        headers: { Authorization: `Bearer ${token}` },
      });

      // ==========================
      // UPDATE
      // ==========================
      if (editingId) {
        alert("Cập nhật thành công!");
        setEditingId(null);
      } else {
        // ==========================
        // CREATE (KHÔNG HỎI CONFIRM)
        // ==========================
        alert("Thêm sản phẩm thành công!");
      }

      // Reset form
      setForm({
        name: "",
        description: "",
        price: "",
        image_url: "",
        gender: "unisex",
        category_id: "",
      });

      window.dispatchEvent(new Event("categories-updated"));

      // Reload UI
      await fetchData();
    } catch (err) {
      alert("Lỗi lưu sản phẩm!");
    }
  };

  // ==========================
  // EDIT PRODUCT
  // ==========================
  const handleEdit = (p) => {
    setForm({
      name: p.name,
      description: p.description || "",
      price: p.price,
      image_url: p.image_url || "",
      gender: p.gender,
      category_id: p.category_id,
    });

    setEditingId(p.id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // ==========================
  // DELETE PRODUCT
  // ==========================
  const handleDelete = async (id) => {
    if (!window.confirm("Chắc chắn xóa?")) return;

    try {
      await API.delete(`/admin/products/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      setProducts(products.filter((p) => p.id !== id));
    } catch {
      alert("Lỗi xóa!");
    }
  };

  // ==========================
  // UI
  // ==========================
  return (
    <div className="container mx-auto p-4">
      {/* HEADER */}
      <div className="flex justify-between items-center mb-6 border-b pb-2">
        <h2 className="text-2xl font-bold uppercase text-gray-800">QUẢN LÝ SẢN PHẨM</h2>

        <button
          onClick={() => (window.location.href = "/admin/categories")}
          className="px-4 py-2 bg-violet-600 text-white rounded-lg font-semibold hover:bg-violet-700"
        >
          Quản lý danh mục
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">

        {/* FORM BÊN TRÁI */}
        <div className="lg:col-span-4 bg-white p-6 rounded-lg shadow-lg border border-gray-200">
          <h3 className="font-bold text-lg mb-4 text-violet-600 border-b pb-2">
            {editingId ? "Sửa thông tin chung" : "Tạo sản phẩm mới"}
          </h3>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">

            {/* TÊN */}
            <div>
              <label className="text-sm font-bold text-gray-700">Tên sản phẩm</label>
              <input
                className="form-control"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Ví dụ: Áo thun Cotton..."
              />
            </div>

            {/* GIÁ + GIỚI TÍNH */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-sm font-bold">Giá bán</label>
                <input
                  type="number"
                  className="form-control"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: +e.target.value })}
                  placeholder="Nhập giá..."
                />
              </div>

              <div>
                <label className="text-sm font-bold">Giới tính</label>
                <select
                  className="form-select"
                  value={form.gender}
                  onChange={(e) => setForm({ ...form, gender: e.target.value })}
                >
                  <option value="unisex">Unisex</option>
                  <option value="male">Nam</option>
                  <option value="female">Nữ</option>
                </select>
              </div>
            </div>

            {/* DANH MỤC */}
            <div>
              <label className="text-sm font-bold">Danh mục</label>
              <select
                className="form-select"
                value={form.category_id}
                onChange={(e) => setForm({ ...form, category_id: e.target.value })}
              >
                <option value="">-- Chọn --</option>
                {categories
                  .filter((c) => c.gender === form.gender)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
              </select>
            </div>

            {/* ẢNH */}
            <div>
              <label className="text-sm font-bold">Ảnh đại diện (Chính)</label>

              <input type="file" className="form-control mb-2" onChange={handleFileUpload} />

              <input
                className="form-control text-sm"
                value={form.image_url}
                onChange={(e) => setForm({ ...form, image_url: e.target.value })}
                placeholder="Hoặc nhập link..."
              />

              {uploading && <p className="text-blue-500 text-xs mt-1">Đang tải ảnh...</p>}

              {form.image_url && (
                <div className="mt-2 border rounded p-1">
                  <img
                    src={
                      form.image_url.startsWith("http")
                        ? form.image_url
                        : `${backendUrl}${form.image_url}`
                    }
                    className="w-full h-40 object-cover rounded"
                  />
                </div>
              )}
            </div>

            {/* MÔ TẢ */}
            <div>
              <label className="text-sm font-bold">Mô tả</label>
              <textarea
                className="form-control"
                rows="3"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>

            {/* NÚT */}
            <div className="flex gap-2">
              <button
                type="submit"
                className={`btn w-full ${
                  editingId
                    ? "btn-warning"
                    : "bg-violet-600 text-white border-violet-600 hover:bg-violet-700"
                }`}
              >
                {editingId ? "Cập nhật thông tin" : "Tạo sản phẩm"}
              </button>

              {editingId && (
                <button
                  type="button"
                  onClick={() => {
                    setEditingId(null);
                    setForm({
                      name: "",
                      description: "",
                      price: "",
                      image_url: "",
                      gender: "unisex",
                      category_id: "",
                    });
                  }}
                  className="btn btn-secondary"
                >
                  Hủy
                </button>
              )}
            </div>
          </form>
        </div>

        {/* LIST BÊN PHẢI */}
        <div className="lg:col-span-8">

          {/* FILTER BAR */}
          <div className="bg-white p-4 rounded-lg shadow-sm mb-4 flex flex-wrap gap-4 justify-between items-center border border-gray-200">

            {/* GIỚI TÍNH */}
            <div className="flex gap-2">
              {["all", "male", "female", "unisex"].map((g) => (
                <button
                  key={g}
                  onClick={() => setFilterGender(g)}
                  className={`btn btn-sm ${
                    filterGender === g ? "btn-dark" : "btn-outline-secondary"
                  }`}
                >
                  {g === "all" ? "Tất cả" : g === "male" ? "Nam" : g === "female" ? "Nữ" : "Unisex"}
                </button>
              ))}
            </div>

            {/* DANH MỤC LISTBOX */}
            <div className="relative -ml-4">
              <Listbox value={filterCategory} onChange={setFilterCategory}>
                <div className="relative">
                  <Listbox.Button
                    className="
                      px-6 py-2 rounded-full border border-gray-300 bg-white
                      shadow-sm cursor-pointer text-gray-700 font-semibold
                      flex items-center justify-between gap-2
                      w-[250px]
                      hover:border-violet-500
                      focus:ring-2 focus:ring-violet-600
                    "
                  >
                    <span>
                      {filterCategory === "all"
                        ? "Tất cả danh mục"
                        : (filterGender === "all"
                            ? sortGenderOrder(categories)
                            : categories.filter((c) => c.gender === filterGender)
                          ).find((c) => c.id == filterCategory)?.name}
                    </span>

                    <FaChevronDown className="text-gray-500 text-sm" />
                  </Listbox.Button>

                  <Transition
                    as={Fragment}
                    leave="transition ease-in duration-100"
                    leaveFrom="opacity-100"
                    leaveTo="opacity-0"
                  >
                    <Listbox.Options
                      className="
                        absolute mt-2 w-full bg-white shadow-xl rounded-xl
                        max-h-60 overflow-auto border border-gray-200 py-2 z-50
                      "
                    >
                      <Listbox.Option
                        value="all"
                        className={({ active }) =>
                          `px-4 py-2 cursor-pointer text-center font-semibold
                           ${active ? "bg-violet-100 text-violet-700" : "text-gray-700"}`
                        }
                      >
                        Tất cả danh mục
                      </Listbox.Option>

                      {(filterGender === "all"
                        ? categories
                        : categories.filter((c) => c.gender === filterGender)
                      ).map((c) => (
                        <Listbox.Option
                          key={c.id}
                          value={c.id}
                          className={({ active }) =>
                            `px-4 py-2 cursor-pointer text-center
                             ${active ? "bg-violet-100 text-violet-700" : "text-gray-700"}`
                          }
                        >
                          {c.name}
                        </Listbox.Option>
                      ))}
                    </Listbox.Options>
                  </Transition>
                </div>
              </Listbox>
            </div>

            {/* SEARCH */}
            <input
              className="form-control w-auto rounded-pill"
              placeholder="Tìm kiếm..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* GRID SẢN PHẨM */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {filteredProducts.map((p) => (
              <div
                key={p.id}
                className="card h-100 cursor-pointer group bg-white"
                onClick={() => navigate(`/admin/products/${p.id}`)}
              >
                <div className="relative h-48 overflow-hidden bg-gray-100">
                  {p.image_url ? (
                    <img
                      src={p.image_url.startsWith("http") ? p.image_url : `${backendUrl}${p.image_url}`}
                      className="w-full h-full object-cover group-hover:scale-105 transition"
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full text-gray-400">
                      <i className="fa-solid fa-image fa-2x" />
                    </div>
                  )}

                  <span
                    className={`absolute top-2 right-2 badge ${
                      p.gender === "male"
                        ? "bg-primary"
                        : p.gender === "female"
                        ? "bg-danger"
                        : "bg-success"
                    }`}
                  >
                    {p.gender === "male" ? "Nam" : p.gender === "female" ? "Nữ" : "Unisex"}
                  </span>
                </div>

                <div className="card-body p-3">
                  <div className="text-xs text-muted uppercase mb-1">{p.category_name}</div>

                  <h6 className="card-title text-truncate font-bold">{p.name}</h6>

                  <div className="d-flex justify-content-between items-center mt-2">
                    <div className="text-danger fw-bold">
                      {Number(p.price).toLocaleString()}đ
                    </div>

                    <div className="btn-group">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEdit(p);
                        }}
                        className="btn btn-sm btn-light text-warning"
                      >
                        <i className="fas fa-pen" />
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(p.id);
                        }}
                        className="btn btn-sm btn-light text-danger"
                      >
                        <i className="fas fa-trash" />
                      </button>
                    </div>
                  </div>

                  <div className="mt-2 text-xs text-gray-500 border-t pt-2">
                    Kho: <strong>{p.total_stock || 0}</strong> | Bấm để quản lý size
                  </div>
                </div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </div>
  );
}

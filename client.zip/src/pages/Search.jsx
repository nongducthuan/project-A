import { useState, useEffect, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import API from "../api.jsx";
import ProductCard from "../components/ProductCard.jsx";

// --- HÀM HELPER: BỎ DẤU TIẾNG VIỆT ---
const removeVietnameseTones = (str) => {
  if (!str) return "";
  str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
  str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
  str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
  str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
  str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
  str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
  str = str.replace(/đ/g, "d");
  str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "A");
  str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "E");
  str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "I");
  str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "O");
  str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "U");
  str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "Y");
  str = str.replace(/Đ/g, "D");
  // Kết hợp các dấu thanh (nếu có)
  str = str.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  return str;
};

const PRICE_RANGES = [
  { label: "Tất cả", min: 0, max: Infinity },
  { label: "< 100k", min: 0, max: 100000 },
  { label: "100k - 300k", min: 100000, max: 300000 },
  { label: "300k - 500k", min: 300000, max: 500000 },
  { label: "> 500k", min: 500000, max: Infinity },
];

const GENDERS = [
  { id: "all", label: "Tất cả" },
  { id: "male", label: "Nam" },
  { id: "female", label: "Nữ" },
  { id: "unisex", label: "Unisex" },
];

export default function SearchResults() {
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);

  // Lấy params từ URL
  const [searchParams, setSearchParams] = useSearchParams();
  const urlQuery = searchParams.get("query") || "";
  const urlGender = searchParams.get("gender") || "all";
  const urlCategory = searchParams.get("category") || "";

  // State local
  const [searchInput, setSearchInput] = useState(urlQuery); // Input nhập liệu
  const [filterPrice, setFilterPrice] = useState(0);

  // Sync Input khi URL thay đổi (ví dụ user ấn Back browser)
  useEffect(() => {
    setSearchInput(urlQuery);
  }, [urlQuery]);

  // Fetch Data
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [prodRes, catRes] = await Promise.all([
          API.get("/products?limit=2000"),
          API.get("/categories"),
        ]);

        const prodData = Array.isArray(prodRes.data) ? prodRes.data : prodRes.data?.data || [];
        const catData = Array.isArray(catRes.data) ? catRes.data : catRes.data?.data || [];

        setProducts(prodData);
        setCategories(catData);
      } catch (err) {
        console.error("Lỗi tải dữ liệu:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  // Xử lý danh mục trùng tên
  const uniqueCategories = useMemo(() => {
    const unique = [];
    const seenNames = new Set();
    categories.forEach((cat) => {
      const nameKey = cat.name.trim().toLowerCase();
      if (!seenNames.has(nameKey)) {
        seenNames.add(nameKey);
        unique.push(cat);
      }
    });
    return unique;
  }, [categories]);

  // --- LOGIC LỌC SẢN PHẨM CHÍNH ---
  const filteredProducts = useMemo(() => {
    if (!products.length) return [];

    return products.filter((p) => {
      // 1. Lọc theo từ khóa (So sánh chuỗi không dấu)
      const productNameNorm = removeVietnameseTones(p.name).toLowerCase();
      const queryNorm = removeVietnameseTones(urlQuery).toLowerCase();
      const matchQuery = productNameNorm.includes(queryNorm);

      // 2. Lọc theo Giới tính
      let matchGender = true;
      if (urlGender !== "all") {
        matchGender = p.gender === urlGender;
      }

      // 3. Lọc theo Danh mục (Xử lý ID trùng tên)
      let matchCategory = true;
      if (urlCategory) {
        const currentCategory = categories.find((c) => String(c.id) === String(urlCategory));
        if (currentCategory) {
          const sameNameCategoryIds = categories
            .filter((c) => c.name.trim().toLowerCase() === currentCategory.name.trim().toLowerCase())
            .map((c) => String(c.id));
          matchCategory = sameNameCategoryIds.includes(String(p.category_id));
        } else {
          matchCategory = String(p.category_id) === String(urlCategory);
        }
      }

      // 4. Lọc theo Giá
      const selectedRange = PRICE_RANGES[filterPrice];
      const price = Number(p.price);
      const matchPrice = price >= selectedRange.min && price < selectedRange.max;

      return matchQuery && matchGender && matchCategory && matchPrice;
    });
  }, [products, urlQuery, urlGender, urlCategory, filterPrice, categories]);

  // Handle Search Input Submit
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    const newParams = new URLSearchParams(searchParams);
    
    // Nếu input trống thì xóa query khỏi URL, ngược lại thì set
    if (searchInput.trim()) {
      newParams.set("query", searchInput);
    } else {
      newParams.delete("query");
    }
    
    // Giữ lại các bộ lọc khác nếu muốn, hoặc reset tùy logic
    // Ở đây mình giữ nguyên logic hiện tại
    setSearchParams(newParams);
  };

  // Handle Update Sidebar Filters
  const updateFilter = (key, value) => {
    if (key === "price") {
      setFilterPrice(value);
      return; // Giá chỉ lưu local state, không đẩy lên URL (theo code cũ)
    }

    const newParams = new URLSearchParams(searchParams);
    if (value && value !== "all") newParams.set(key, value);
    else newParams.delete(key);
    
    setSearchParams(newParams);
  };

  if (loading) return <div className="flex justify-center items-center h-64 text-gray-500">Đang tải...</div>;

  return (
    <div className="container mx-auto py-8 px-4 min-h-screen flex flex-col md:flex-row gap-8">
      {/* SIDEBAR */}
      <div className="w-full md:w-1/4 flex-shrink-0">
        <div className="sticky top-24 bg-white p-4 rounded-lg border border-gray-200 shadow-sm max-h-[calc(100vh-120px)] overflow-y-auto custom-scrollbar">
          <div className="flex justify-between items-center mb-4 border-b pb-2">
            <h3 className="font-bold text-lg uppercase text-gray-800">Bộ lọc</h3>
            <button
              className="text-xs text-red-500 hover:underline"
              onClick={() => {
                setSearchParams({});
                setFilterPrice(0);
                setSearchInput("");
              }}
            >
              Xóa tất cả
            </button>
          </div>

          {/* Giới tính */}
          <div className="mb-6">
            <h4 className="font-semibold text-sm mb-3 text-gray-700">Giới tính</h4>
            <div className="flex flex-wrap gap-2">
              {GENDERS.map((g) => (
                <button
                  key={g.id}
                  onClick={() => updateFilter("gender", g.id)}
                  className={`px-3 py-1.5 text-sm border rounded transition-all ${
                    urlGender === g.id
                      ? "bg-black text-white border-black"
                      : "bg-white text-gray-600 border-gray-300 hover:border-gray-500"
                  }`}
                >
                  {g.label}
                </button>
              ))}
            </div>
          </div>

          {/* Danh mục */}
          <div className="mb-6">
            <h4 className="font-semibold text-sm mb-3 text-gray-700">Danh mục</h4>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => updateFilter("category", "")}
                className={`px-2 py-2 text-sm border rounded text-center transition-all ${
                  !urlCategory
                    ? "bg-black text-white border-black"
                    : "bg-white text-gray-600 border-gray-300 hover:border-gray-500"
                }`}
              >
                Tất cả
              </button>
              {uniqueCategories.map((c) => {
                const currentSelectedCat = categories.find((cat) => String(cat.id) === String(urlCategory));
                const isSelected = currentSelectedCat && currentSelectedCat.name === c.name;

                return (
                  <button
                    key={c.id}
                    onClick={() => updateFilter("category", c.id)}
                    className={`px-2 py-2 text-sm border rounded text-center truncate ${
                      isSelected
                        ? "bg-black text-white border-black"
                        : "bg-white text-gray-600 border-gray-300 hover:border-gray-500"
                    }`}
                    title={c.name}
                  >
                    {c.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Giá tiền */}
          <div className="mb-6">
            <h4 className="font-semibold text-sm mb-3 text-gray-700">Mức giá</h4>
            <div className="grid grid-cols-1 gap-2">
              {PRICE_RANGES.map((range, index) => (
                <button
                  key={index}
                  onClick={() => updateFilter("price", index)}
                  className={`px-3 py-2 text-sm border rounded text-left transition-all ${
                    filterPrice === index
                      ? "bg-black text-white border-black"
                      : "bg-white text-gray-600 border-gray-300 hover:border-gray-500"
                  }`}
                >
                  {range.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* DANH SÁCH SẢN PHẨM */}
      <div className="w-full md:w-3/4">
        
        {/* --- FORM TÌM KIẾM --- */}
        <div className="mb-6 bg-white p-4 rounded-lg shadow-sm border border-gray-100">
           <form onSubmit={handleSearchSubmit} className="flex gap-2">
             <input 
               type="text"
               className="flex-1 border border-gray-300 rounded-md px-4 py-2 focus:ring-2 focus:ring-black focus:outline-none transition"
               placeholder="Tìm kiếm sản phẩm"
               value={searchInput}
               onChange={(e) => setSearchInput(e.target.value)}
             />
             <button 
               type="submit"
               className="bg-black text-white px-6 py-2 rounded-md font-bold hover:bg-gray-800 transition flex items-center gap-2"
             >
               <i className="fa-solid fa-magnifying-glass"></i>
               Tìm
             </button>
           </form>
        </div>

        <div className="flex justify-between items-end mb-6">
          <div>
            <h2 className="text-2xl font-bold uppercase text-gray-800">
              {urlQuery ? `Kết quả: "${urlQuery}"` : "Tất cả sản phẩm"}
            </h2>
            <p className="text-sm text-gray-500 mt-1">Hiển thị {filteredProducts.length} sản phẩm</p>
          </div>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="text-center py-20 bg-gray-50 rounded-lg border border-dashed border-gray-300">
            <p className="text-gray-500 text-lg">Không tìm thấy sản phẩm nào phù hợp.</p>
            <button
              className="mt-4 text-sm text-blue-600 hover:underline"
              onClick={() => {
                setSearchParams({});
                setSearchInput("");
              }}
            >
              Xóa bộ lọc
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
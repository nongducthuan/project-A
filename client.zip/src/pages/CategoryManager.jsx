import { useEffect, useState } from "react";
import API from "../api";

export default function CategoryManager() {
  /* ============================================================
   * 1) STATE
   * ============================================================ */
  const [categories, setCategories] = useState([]);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(false);

  const [filterGender, setFilterGender] = useState("male");

  const [categoryImages, setCategoryImages] = useState([]);
  const [recommendNames, setRecommendNames] = useState([]);

  const token = localStorage.getItem("token");
  const auth = { headers: { Authorization: `Bearer ${token}` } };

  const [form, setForm] = useState({
    name: "",
    gender: "",
    image_url: "",
  });

  /* ============================================================
   * 2) FETCH CATEGORIES
   * ============================================================ */
  async function fetchCategories() {
    const res = await API.get("/categories");
    let list = Array.isArray(res.data) ? res.data : res.data.data;

    // Sắp xếp theo gender: male → female → unisex
    const order = { male: 1, female: 2, unisex: 3 };
    list = [...list].sort((a, b) => order[a.gender] - order[b.gender]);

    setCategories(list || []);
  }

  useEffect(() => {
    fetchCategories();
  }, []);

  /* ============================================================
   * 3) FORM HANDLERS
   * ============================================================ */
  async function handleChange(e) {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    // Khi đổi giới tính → load suggest danh mục
    if (name === "gender" && value) {
      const res = await API.get(`/categories/recommend?gender=${value}`);
      setRecommendNames(res.data.data || []);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);

    try {
      if (editingId) {
        await API.put(`/categories/${editingId}`, form, auth);
      } else {
        await API.post("/categories", form, auth);
      }

      resetForm();
      await fetchCategories();
      window.dispatchEvent(new Event("categories-updated"));
    } catch (err) {
      alert("Lỗi lưu danh mục");
    }

    setLoading(false);
  }

  function resetForm() {
    setEditingId(null);
    setForm({ name: "", gender: "", image_url: "" });
    setCategoryImages([]);
    setRecommendNames([]);
  }

  /* ============================================================
   * 4) EDIT + DELETE
   * ============================================================ */
  async function handleEdit(cat) {
    setEditingId(cat.id);

    setForm({
      name: cat.name,
      gender: cat.gender,
      image_url: cat.image_url || "",
    });

    // Load ảnh sản phẩm liên quan
    const res = await API.get(`/categories/${cat.id}/images`);
    setCategoryImages(res.data.data || []);

    // Load suggest
    const res2 = await API.get(
      `/categories/recommend?gender=${cat.gender}`
    );
    setRecommendNames(res2.data.data || []);
  }

  async function handleDelete(id) {
    if (!window.confirm("Xóa danh mục này?")) return;

    try {
      await API.delete(`/categories/${id}`, auth);
      await fetchCategories();
    } catch (err) {
      alert("Không thể xóa danh mục đang chứa sản phẩm");
    }
  }

  /* ============================================================
   * 5) UI HELPERS
   * ============================================================ */
  const genderLabel = (g) =>
    g === "male" ? "Nam" : g === "female" ? "Nữ" : "Unisex";

  const genderTabs = [
    { key: "male", label: "Nam" },
    { key: "female", label: "Nữ" },
    { key: "unisex", label: "Unisex" },
  ];

  /* ============================================================
   * 6) RENDER UI
   * ============================================================ */
  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* HEADER */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900">QUẢN LÝ DANH MỤC</h1>
        <button
          onClick={() => (window.location.href = "/admin/products")}
          className="px-4 py-2 bg-violet-600 text-white rounded-lg font-semibold hover:bg-violet-700"
        >
          Quản lý sản phẩm
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        {/* ================= FORM BÊN TRÁI ================= */}
        <div className="bg-white shadow-xl rounded-xl border p-6 h-fit sticky top-20">
          <h3 className="text-xl font-bold mb-4 text-gray-700">
            {editingId ? "Chỉnh sửa danh mục" : "Thêm danh mục mới"}
          </h3>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* TÊN DANH MỤC */}
            <div>
              <label className="block font-medium mb-1">Tên danh mục</label>
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-violet-500"
              />

              {/* GỢI Ý DANH MỤC */}
              {recommendNames.length > 0 && (
                <div className="mt-2 p-3 border rounded-lg bg-violet-50">
                  <p className="font-semibold text-sm text-violet-700 mb-2">
                    Gợi ý danh mục chưa có:
                  </p>

                  <div className="flex flex-wrap gap-2">
                    {recommendNames.map((item, idx) => (
                      <button
                        key={idx}
                        type="button"
                        onClick={() =>
                          setForm({ ...form, name: item.name })
                        }
                        className="px-3 py-1 bg-white border rounded-lg shadow-sm hover:bg-violet-100"
                      >
                        {item.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* GIỚI TÍNH */}
            <div>
              <label className="block font-medium mb-1">Giới tính</label>
              <select
                name="gender"
                value={form.gender}
                onChange={handleChange}
                required
                className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-violet-500"
              >
                <option value="">-- Chọn --</option>
                <option value="male">Nam</option>
                <option value="female">Nữ</option>
                <option value="unisex">Unisex</option>
              </select>
            </div>

            {/* ẢNH ĐẠI DIỆN */}
            <div>
              <label className="block font-medium mb-1">Ảnh đại diện</label>

              {editingId && categoryImages.length > 0 ? (
                <div className="grid grid-cols-4 gap-2 bg-gray-50 p-2 rounded border">
                  {categoryImages.map((img, idx) => (
                    <div
                      key={idx}
                      onClick={() =>
                        setForm({ ...form, image_url: img.image_url })
                      }
                      className={`border rounded cursor-pointer overflow-hidden ${
                        form.image_url === img.image_url
                          ? "ring-2 ring-violet-600"
                          : "opacity-80 hover:opacity-100"
                      }`}
                    >
                      <img
                        src={
                          img.image_url.startsWith("http")
                            ? img.image_url
                            : `http://localhost:5000${img.image_url}`
                        }
                        className="w-full h-20 object-cover"
                      />
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 italic text-sm">
                  Chọn danh mục để hiển thị ảnh sản phẩm liên quan.
                </p>
              )}

              {form.image_url && (
                <p className="text-green-600 text-xs mt-1">
                  Ảnh đã chọn: {form.image_url}
                </p>
              )}
            </div>

            {/* BUTTONS */}
            <div className="flex items-center gap-3">
              <button
                disabled={loading}
                className="bg-violet-600 text-white px-5 py-2 rounded-lg font-semibold hover:bg-violet-700"
              >
                {editingId ? "Cập nhật" : "Thêm mới"}
              </button>

              {editingId && (
                <button
                  type="button"
                  className="px-4 py-2 bg-gray-300 rounded-lg"
                  onClick={resetForm}
                >
                  Hủy
                </button>
              )}
            </div>
          </form>
        </div>

        {/* ================= BẢNG DANH MỤC ================= */}
        <div>
          {/* TABS GIỚI TÍNH */}
          <div className="flex gap-4 mb-6">
            {genderTabs.map((t) => (
              <button
                key={t.key}
                onClick={() => setFilterGender(t.key)}
                className={`px-4 py-2 rounded-lg font-semibold border ${
                  filterGender === t.key
                    ? "bg-violet-600 text-white"
                    : "bg-white text-gray-700"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* TABLE */}
          <div className="bg-white shadow-lg rounded-xl border overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-3 border w-28">Ảnh</th>
                  <th className="p-3 border">Tên</th>
                  <th className="p-3 border">Giới tính</th>
                  <th className="p-3 border w-40 text-center">Hành động</th>
                </tr>
              </thead>

              <tbody>
                {categories
                  .filter((cat) => cat.gender === filterGender)
                  .map((cat) => (
                    <tr key={cat.id} className="hover:bg-gray-50">
                      <td className="p-3 border">
                        {cat.image_url ? (
                          <img
                            src={
                              cat.image_url.startsWith("http")
                                ? cat.image_url
                                : `http://localhost:5000${cat.image_url}`
                            }
                            className="w-14 h-14 object-cover rounded"
                          />
                        ) : (
                          <span className="text-gray-400 italic">
                            Không có
                          </span>
                        )}
                      </td>

                      <td className="p-3 border">{cat.name}</td>
                      <td className="p-3 border">
                        {genderLabel(cat.gender)}
                      </td>

                      <td className="p-3 border text-center">
                        <button
                          onClick={() => handleEdit(cat)}
                          className="px-3 py-1 bg-blue-500 text-white rounded mr-2"
                        >
                          Sửa
                        </button>
                        <button
                          onClick={() => handleDelete(cat.id)}
                          className="px-3 py-1 bg-red-500 text-white rounded"
                        >
                          Xóa
                        </button>
                      </td>
                    </tr>
                  ))}

                {categories.filter((x) => x.gender === filterGender).length ===
                  0 && (
                  <tr>
                    <td
                      colSpan="5"
                      className="p-4 text-center text-gray-500 italic"
                    >
                      Không có danh mục.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

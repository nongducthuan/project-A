import { Chart } from "react-google-charts";

export default function AdminReport() {
  // ======= Dữ liệu thực tế hơn =======
  const weeklyOrders = 85;
  const monthlyOrders = 320;
  const weeklyRevenue = 145000000;
  const monthlyRevenue = 630000000;
  const productsSoldWeek = 210;
  const productsSoldMonth = 890;

  // ======= Dữ liệu biểu đồ tuần (điều chỉnh thực tế) =======
  const comboChartWeekData = [
    ["Ngày", "Sản phẩm bán", "Đơn hàng"],
    ["Thứ 2", 32, 12],
    ["Thứ 3", 28, 10],
    ["Thứ 4", 35, 14],
    ["Thứ 5", 25, 9],
    ["Thứ 6", 40, 15],
    ["Thứ 7", 30, 12],
    ["CN", 20, 8],
  ];

  const comboChartWeekOptions = {
    title: "Thống kê tuần này",
    vAxis: { title: "Số lượng" },
    hAxis: { title: "Ngày trong tuần" },
    seriesType: "bars",
    legend: { position: "bottom" },
    chartArea: { width: "80%", height: "70%" },
  };

  const lineChartWeekData = [
    ["Ngày", "Doanh thu"],
    ["Thứ 2", 25000000],
    ["Thứ 3", 21000000],
    ["Thứ 4", 30000000],
    ["Thứ 5", 18000000],
    ["Thứ 6", 35000000],
    ["Thứ 7", 23000000],
    ["CN", 13000000],
  ];

  const lineChartWeekOptions = {
    title: "Doanh thu tuần (VNĐ)",
    hAxis: { title: "Ngày" },
    vAxis: { title: "Doanh thu" },
    legend: { position: "bottom" },
    curveType: "function",
    chartArea: { width: "80%", height: "70%" },
  };

  const pieChartWeekData = [
    ["Trạng thái", "Số lượng"],
    ["Chờ xác nhận", 15],
    ["Đã xác nhận", 20],
    ["Đang giao hàng", 18],
    ["Đã giao hàng", 25],
    ["Đã hủy", 7],
  ];

  const pieChartWeekOptions = {
    title: "Tỷ lệ đơn hàng tuần",
    pieHole: 0.4,
    chartArea: { width: "80%", height: "70%" },
    colors: ["#ffc107", "#17a2b8", "#007bff", "#28a745", "#dc3545"],
  };

  // ======= Dữ liệu biểu đồ tháng =======
  const comboChartMonthData = [
    ["Tháng", "Sản phẩm bán", "Đơn hàng"],
    ["1", 70, 25],
    ["2", 75, 28],
    ["3", 80, 30],
    ["4", 72, 26],
    ["5", 85, 32],
    ["6", 90, 35],
    ["7", 78, 28],
    ["8", 82, 30],
    ["9", 88, 33],
    ["10", 92, 35],
    ["11", 95, 36],
    ["12", 100, 40],
  ];

  const comboChartMonthOptions = {
    title: "Thống kê tháng",
    vAxis: { title: "Số lượng" },
    hAxis: { title: "Tháng" },
    seriesType: "bars",
    legend: { position: "bottom" },
    chartArea: { width: "80%", height: "70%" },
  };

  const lineChartMonthData = [
    ["Tháng", "Doanh thu"],
    ["1", 45000000],
    ["2", 48000000],
    ["3", 52000000],
    ["4", 50000000],
    ["5", 55000000],
    ["6", 58000000],
    ["7", 53000000],
    ["8", 52000000],
    ["9", 56000000],
    ["10", 60000000],
    ["11", 62000000],
    ["12", 65000000],
  ];

  const lineChartMonthOptions = {
    title: "Doanh thu tháng (VNĐ)",
    hAxis: { title: "Tháng" },
    vAxis: { title: "Doanh thu" },
    legend: { position: "bottom" },
    curveType: "function",
    chartArea: { width: "80%", height: "70%" },
  };

  const pieChartMonthData = [
    ["Trạng thái", "Số lượng"],
    ["Chờ xác nhận", 40],
    ["Đã xác nhận", 70],
    ["Đang giao hàng", 65],
    ["Đã giao hàng", 120],
    ["Đã hủy", 25],
  ];

  const pieChartMonthOptions = {
    title: "Tỷ lệ đơn hàng tháng",
    pieHole: 0.4,
    chartArea: { width: "80%", height: "70%" },
    colors: ["#ffc107", "#17a2b8", "#007bff", "#28a745", "#dc3545"],
  };

  return (
    <div className="container mx-auto mt-6 px-2 md:px-4">
      <h2 className="text-center text-2xl font-bold mb-6">Báo Cáo Thống Kê</h2>

      {/* ======= Tổng quan nhanh ======= */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="p-4 shadow rounded bg-blue-50 text-center">
          <h4 className="font-semibold text-lg">Đơn hàng tuần</h4>
          <p className="text-2xl font-bold">{weeklyOrders}</p>
        </div>
        <div className="p-4 shadow rounded bg-green-50 text-center">
          <h4 className="font-semibold text-lg">Đơn hàng tháng</h4>
          <p className="text-2xl font-bold">{monthlyOrders}</p>
        </div>
        <div className="p-4 shadow rounded bg-yellow-50 text-center">
          <h4 className="font-semibold text-lg">Doanh thu tuần</h4>
          <p className="text-2xl font-bold">{weeklyRevenue.toLocaleString()}₫</p>
        </div>
        <div className="p-4 shadow rounded bg-purple-50 text-center">
          <h4 className="font-semibold text-lg">Doanh thu tháng</h4>
          <p className="text-2xl font-bold">{monthlyRevenue.toLocaleString()}₫</p>
        </div>
        <div className="p-4 shadow rounded bg-pink-50 text-center">
          <h4 className="font-semibold text-lg">Sản phẩm bán tuần</h4>
          <p className="text-2xl font-bold">{productsSoldWeek}</p>
        </div>
        <div className="p-4 shadow rounded bg-indigo-50 text-center">
          <h4 className="font-semibold text-lg">Sản phẩm bán tháng</h4>
          <p className="text-2xl font-bold">{productsSoldMonth}</p>
        </div>
      </div>

      {/* ======= Báo cáo tuần ======= */}
      <h3 className="text-center text-xl font-bold mb-2">Thống kê tuần</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="w-full h-64 md:h-72">
          <Chart
            chartType="ComboChart"
            width="100%"
            height="100%"
            data={comboChartWeekData}
            options={comboChartWeekOptions}
          />
        </div>
        <div className="w-full h-64 md:h-72">
          <Chart
            chartType="LineChart"
            width="100%"
            height="100%"
            data={lineChartWeekData}
            options={lineChartWeekOptions}
          />
        </div>
        <div className="w-full h-64 md:h-72">
          <Chart
            chartType="PieChart"
            width="100%"
            height="100%"
            data={pieChartWeekData}
            options={pieChartWeekOptions}
          />
        </div>
      </div>

      {/* ======= Báo cáo tháng ======= */}
      <h3 className="text-center text-xl font-bold mb-2">Thống kê tháng</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="w-full h-64 md:h-72">
          <Chart
            chartType="ComboChart"
            width="100%"
            height="100%"
            data={comboChartMonthData}
            options={comboChartMonthOptions}
          />
        </div>
        <div className="w-full h-64 md:h-72">
          <Chart
            chartType="LineChart"
            width="100%"
            height="100%"
            data={lineChartMonthData}
            options={lineChartMonthOptions}
          />
        </div>
        <div className="w-full h-64 md:h-72">
          <Chart
            chartType="PieChart"
            width="100%"
            height="100%"
            data={pieChartMonthData}
            options={pieChartMonthOptions}
          />
        </div>
      </div>
    </div>
  );
}
